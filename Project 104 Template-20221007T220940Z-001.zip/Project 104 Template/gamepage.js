// random value generated
  
// counting the number of guesses
// made for correct Guess

  
// function for number guessed by user     
